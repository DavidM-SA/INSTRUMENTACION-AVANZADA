Practica 1 de Instrumentacion Avanzada.
Documentacion creada Doxygen.
Para abrir la documentacion y poder ver las imagenes adjuntas descomprima el archivo adjunto en "C:\" llamando a la carpeta de descompresion IOT generando asi el siguiente arbol de ruta: "C:\IOT".
Una vez descomprimido, abra el siguiente archivo: "C:\IOT\Documentacion\html\index.html" ahi esta la documetacion.
Si las imagenes no se ven correctamente asegurese que ha generado el arbol correctamente en C:\ y si las fotos no se muestran intente cambiar de explorador, en mi caso con Microsof Edge y con Brave se han visualizado correctamente.

Trabajo realizado por:
David Martín-Sacristán Avilés,
NIA:806131